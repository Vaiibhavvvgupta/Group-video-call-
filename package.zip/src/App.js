import { BrowserRouter, Route, Routes } from 'react-router-dom';
import VideoCallRoom from './components/VideoCallRoom';
import VoiceController from './components/VoiceController';
import Home from './components/Home';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/room/:roomId" element={<VoiceController />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
